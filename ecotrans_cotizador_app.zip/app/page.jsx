'use client';
import React, { useMemo, useState } from "react";

const routes = {
  "Santiago|Iquique": 1859,
  "Santiago|Antofagasta": 1365,
  "Santiago|Calama": 1540
};

const paymentAdjustments = {
  adelantado: -0.04,
  contado: 0,
  "15_dias": 0.03,
  "30_dias": 0.07,
};

function clp(v){ return new Intl.NumberFormat("es-CL",{style:"currency",currency:"CLP",maximumFractionDigits:0}).format(v||0)}

export default function Page(){
  const [form,setForm]=useState({
    servicio:"consolidado",
    origen:"Santiago",
    destino:"Iquique",
    pallets:6,
    pesoKg:6000,
    volumenM3:12,
    retiro:true,
    ultimaMilla:true,
    formaPago:"contado"
  });

  const distance = routes[form.origen+"|"+form.destino]||0;

  const calc = useMemo(()=>{
    const rateFullTruckMin=2000;
    const posicionesMax=22;
    const capacidadKg=25000;
    const capacidadM3=75;

    const tramos=[
      {min:0,max:5000,val:100000},
      {min:5001,max:10000,val:130000},
      {min:10001,max:15000,val:160000},
      {min:15001,max:20000,val:190000},
      {min:20001,max:26000,val:230000},
      {min:26001,max:999999,val:300000}
    ];
    const tramo=tramos.find(t=>form.pesoKg>=t.min&&form.pesoKg<=t.max);
    const retiro=form.retiro?(tramo?.val||0):0;
    const ultima=form.ultimaMilla?(tramo?.val||0):0;

    const valorRampla=distance*rateFullTruckMin;

    const posP=form.pallets;
    const posKg=(form.pesoKg/capacidadKg)*posicionesMax;
    const posM3=(form.volumenM3/capacidadM3)*posicionesMax;
    const pos=Math.max(posP,posKg,posM3);

    let subtotal=form.servicio==="consolidado"?pos*(valorRampla/posicionesMax):valorRampla;

    const ajuste=subtotal*paymentAdjustments[form.formaPago];
    const neto=subtotal+retiro+ultima+ajuste;
    const iva=neto*0.19;
    return {neto,iva,total:neto+iva};
  },[form,distance]);

  return (
    <div style={{padding:20}}>
      <h1>Ecotrans Cotizador</h1>
      <p>Ruta: {form.origen} → {form.destino} ({distance} km)</p>
      <p>Total: {clp(calc.total)}</p>
    </div>
  );
}
